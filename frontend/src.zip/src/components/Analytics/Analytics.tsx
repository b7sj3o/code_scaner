// src/components/Layout.tsx
import React from 'react';
import "./Analytics.scss";



const Analytics: React.FC = () => {
    return (
        <div style={{fontSize: "35px", textAlign: "center", marginTop: "20кpx"}}>
            Coming soon...
        </div>
    );
};

export default Analytics;
