import React, { useState } from "react"
import { Product } from "../types/product"


export const Config = () => {
    const [lastProduct, setLastProduct] = useState<Product>(Object);
}