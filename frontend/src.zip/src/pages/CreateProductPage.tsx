import React from 'react';
import ProductForm from '../components/ProductForm/ProductForm';

const CreateProductPage: React.FC = () => {
    return (
        <div>
            <ProductForm />
        </div>
    )
}

export default CreateProductPage;