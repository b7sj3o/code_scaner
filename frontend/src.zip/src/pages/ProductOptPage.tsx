import React from 'react';
import ProductOpt from '../components/ProductOpt/ProductOpt';

const ProductOptPage: React.FC = () => {
    return (
        <div>
            <ProductOpt />
        </div>
    );
};

export default ProductOptPage;
