import React from 'react';
import Scanner from '../components/Scanner/Scanner';


const ScannerPage: React.FC = () => {
    return (
        <div>
            <Scanner />
        </div>
    );
};

export default ScannerPage;
