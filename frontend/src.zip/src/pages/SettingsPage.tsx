// src/pages/HomePage.tsx
import React from 'react';
import Settings from '../components/Settings/Settings';

const SettingsPage: React.FC = () => {
    return (
        <Settings />
    );
};

export default SettingsPage;
