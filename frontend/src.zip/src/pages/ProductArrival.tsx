import React from 'react';
import ProductArrival from '../components/ProductArrival/ProductArrival';


const ProductArrivalPage: React.FC = () => {
    return (
        <div>
            <ProductArrival />
        </div>
    );
};

export default ProductArrivalPage;
